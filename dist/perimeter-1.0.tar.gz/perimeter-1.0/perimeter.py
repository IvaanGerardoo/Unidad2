def perimeter_kite (b:float, a:float)->float:
    return 2*(b+a)


def area_kite (D:float, d:float)->float:
    return D*d/2


