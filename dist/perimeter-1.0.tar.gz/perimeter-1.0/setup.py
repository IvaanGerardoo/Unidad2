from setuptools import setup


setup(
    name= 'perimeter',
    version=1.0,
    description='This module calculate perimeter of kite',
    author='Ivan Gerardo Suarez Luna',
    author_email='ivan15gsl@hotmail.com',
    url='http://www.utng.edu.mx',
    py_modules=['perimeter']
)